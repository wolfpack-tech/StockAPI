from flask import Blueprint, jsonify, request
from flask_jwt_extended import jwt_required, get_jwt_identity
from .basedd import get_db_connection


v1_blueprint = Blueprint('V1', __name__)


# Ajouter un produit
@v1_blueprint.route('/add_product', methods=['POST'])
@jwt_required()
def add_product():
    data = request.get_json()
    # name = data.get('name')
    # quantity = data.get('quantity')
    # price = data.get('price')

    user_id = get_jwt_identity()
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute("INSERT INTO products (user_id, nomprod, quantity, price) VALUES (?, ?, ?, ?)",
                   (user_id, data["nomprod"], data["quantity"], data["price"]))
    
    conn.commit()
    conn.close()
    
    return jsonify({"message": "Product added successfully"}), 201

# Mettre à jour le stock d'un produit
@v1_blueprint.route('/update_stock/<int:product_id>', methods=['PUT'])
@jwt_required()
def update_stock(product_id):
    data = request.json
    user_id = get_jwt_identity()
    conn = get_db_connection()
    cursor = conn.cursor()

    quantity = data.get("quantity")
    
    if quantity is None:
        return jsonify({"message": "Quantity is missing"}), 400

    cursor.execute("UPDATE products SET quantity = ? WHERE id = ? AND user_id = ?",
                   (quantity, product_id, user_id))

    conn.commit()
    conn.close()

    return jsonify({"message": "Stock updated successfully"}), 200


# Obtenir la liste des produits de l'utilisateur
@v1_blueprint.route('/products', methods=['GET'])
@jwt_required()
def get_products():
    user_id = get_jwt_identity()  # Obtient l'ID de l'utilisateur à partir du token JWT
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute("SELECT * FROM products WHERE user_id = ?", (user_id,))
    products = cursor.fetchall()
    
    conn.close()
    
    return jsonify([dict(product) for product in products]), 200