
from flask import Flask
from flask_mail import Mail, Message


app = Flask(__name__)

app.config['MAIL_SERVER'] = '34.235.44.11'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USE_SSL'] = False
app.config['MAIL_USERNAME'] = 'wolfhacker@lupusdev.ninja'
app.config['MAIL_PASSWORD'] = 'wolf20$#K'

mail = Mail(app)


def send_registration_email(username, password, cle_api, email):
    msg = Message('Bienvenue sur StockAPI',
                  sender='wolfhacker@lupusdev.ninja',
                  recipients=[email])
    
    msg.body = f'''
    Bonjour {username},

    Merci de vous être inscrit sur StockAPI.

    Voici vos détails de connexion :
    Nom d'utilisateur : {username}
    Mot de passe : {password}
    Clé API : {cle_api}

    Cordialement,
    L'équipe StockAPI
    '''

    mail.send(msg)