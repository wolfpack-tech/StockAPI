from flask import Flask, request, jsonify, redirect, url_for, render_template
from App.v1.routes import v1_blueprint
from App.v1 import basedd
from App.v1.mail import send_registration_email
from flask_jwt_extended import JWTManager, jwt_required, create_access_token, get_jwt_identity
import sqlite3
import secrets
import datetime
from werkzeug.security import generate_password_hash, check_password_hash
from flask_mail import Mail, Message




app = Flask(__name__)

app.register_blueprint(v1_blueprint, url_prefix='/V1')

app.config['JWT_SECRET_KEY'] = 'super-secret'  # Changez cette clé en une valeur sécurisée dans un environnement de production
app.config['JWT_ACCESS_TOKEN_EXPIRES'] = datetime.timedelta(hours=24)
app.config['JWT_TOKEN_TYPE'] = 'Bearer'
app.config['JWT_ALGORITHM'] = 'HS256'
jwt = JWTManager(app)


app.config['MAIL_SERVER'] = '34.235.44.11'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USE_SSL'] = False
app.config['MAIL_USERNAME'] = 'wolfhacker@lupusdev.ninja'
app.config['MAIL_PASSWORD'] = 'wolf20$#K'

mail = Mail(app)


basedd.create_tables()

@app.route('/')
def home():
    return render_template('index.html')


# Enregistrement (Register) d'un nouvel utilisateur
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        email = request.form['email']
        
        conn = basedd.get_db_connection()
        cursor = conn.cursor()

        try:
            hashed_password = generate_password_hash(password, method='pbkdf2:sha256')
            cle_api = secrets.token_hex(12).upper()  # Génère un code API de 12 caractères
            access_token = create_access_token(identity=username)
            expiration_date = datetime.datetime.now() + datetime.timedelta(days=7)
            token = secrets.token_hex(16)

            cursor.execute("INSERT INTO users (username, password, cle_api, access_token, email) VALUES (?, ?, ?, ?, ?)",
                           (username, hashed_password, cle_api, access_token, email))
            user_id = cursor.lastrowid
            
            cursor.execute("INSERT INTO tokens (user_id, token, expiration_date) VALUES (?, ?, ?)",
                           (user_id, token, expiration_date.strftime('%Y-%m-%d %H:%M:%S')))
            
            conn.commit()
            
            send_registration_email(username, password, cle_api, email)
            
            return redirect(url_for('token'))
        except sqlite3.IntegrityError:
            return jsonify({"msg": "Username or email already exists"}), 400
        finally:
            conn.close()

    return render_template('register.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    return render_template('connect.html')
# Authentification
@app.route('/token', methods=['GET', 'POST'])
def token():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        conn = basedd.get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute("SELECT * FROM users WHERE username = ?", (username,))
        user = cursor.fetchone()
        
        

        if user and check_password_hash(user['password'], password):
            access_token = create_access_token(identity=user['id'])
            cursor.execute("UPDATE users SET access_token = ? WHERE id = ?", (access_token, user['id']))
    
            conn.commit()
            conn.close()


            return jsonify(access_token=access_token), 200
            
        else:
            return jsonify({"msg": "Invalid credentials"}), 401

    return render_template('token.html',)


@app.route('/dashboard', methods=['GET', 'POST'])
@jwt_required()
def dashboard():
    if request.method == 'GET':
        return get_dashboard()
    elif request.method == 'POST':
        return post_dashboard()

def get_dashboard():
    user_id = get_jwt_identity()
    conn = basedd.get_db_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM users WHERE id = ?", (user_id,))
    user = cursor.fetchone()
    
    conn.close()

    if user:
        return jsonify({
            "username": user['username'],
            "cle_api": user['cle_api']
        }), 200
    else:
        return jsonify({"msg": "User not found"}), 404

def post_dashboard():
    data = request.form
    
    if not data or 'username' not in data or 'password' not in data or 'cle_api' not in data:
        return jsonify({"msg": "Missing required fields"}), 400

    username = data['username']
    password = data['password']
    cle_api = data['cle_api']
    

    user_id = get_jwt_identity()
    conn = basedd.get_db_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM users WHERE id = ?", (user_id,))
    user = cursor.fetchone()

    if user:
        if user['username'] == username and check_password_hash(user['password'], password) and user['cle_api'] == cle_api :
            return render_template('dashboard.html')
        else:
            return jsonify({"msg": "Invalid credentials"}), 401
    else:
        return jsonify({"msg": "User not found"}), 404
    

def send_registration_email(username, password, cle_api, email):
    msg = Message('Bienvenue sur StockAPI',
                  sender='wolfhacker@lupusdev.ninja',
                  recipients=[email])
    
    msg.body = f'''
    Bonjour {username},

    Merci de vous être inscrit sur StockAPI.

    Voici vos détails de connexion :
    Nom d'utilisateur : {username}
    Mot de passe : {password}
    Clé API : {cle_api}

    Cordialement,
    L'équipe StockAPI
    '''

    mail.send(msg)



    



if __name__ == '__main__':
    app.run(debug=True)
    
