document.querySelector('form').addEventListener('submit', async function(e) {
    e.preventDefault();
  
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    async function login() {
        const response = await fetch('/login', {method: 'post'});
        const result = await response.json();
        localStorage.setItem('access_token', result.access_token);
      }
  
    try {
      const response = await fetch('/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'Authorization': `Bearer ${localStorage.getItem('access_token')}`,
        },
        // body: `username=${username}&password=${password}`
      });
  
      if (response.ok) {
        const data = await response.json();
        localStorage.setItem('access_token', data.access_token);
        window.location.href = '/dashboard';
      } else {
        const error = await response.text();
        document.getElementById('message').textContent = error;
      }
    } catch (error) {
      console.error('Error during login:', error);
      document.getElementById('message').textContent = 'An error occurred.';
    }
  });